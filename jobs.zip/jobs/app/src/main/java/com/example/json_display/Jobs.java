package com.example.json_display;

public class Jobs {
    private String CompanyName;
    private String title;
    private String location;
    private String images;

    public Jobs(){}
    public Jobs(String companyName, String title, String location, String images) {
        CompanyName = companyName;
        this.title = title;
        this.location = location;
        this.images = images;
    }

    public String getCompanyName() {
        return CompanyName;
    }

    public void setCompanyName(String companyName) {
        CompanyName = companyName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }
}
