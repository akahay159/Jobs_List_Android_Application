package com.example.json_display;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    LayoutInflater layoutInflater;
    List<Jobs> jobs;
    public Adapter(Context ctx, List<Jobs> jobs){
        this.layoutInflater = LayoutInflater.from(ctx);
        this.jobs = jobs;

    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.custom_list_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.companyname.setText(jobs.get(position).getCompanyName());
        holder.title.setText(jobs.get(position).getTitle());
        holder.location.setText(jobs.get(position).getLocation());
        // setting the images using Picassso.
        Picasso.get().load(jobs.get(position).getImages()).into(holder.coverimage);
    }

    @Override
    public int getItemCount() {
        return jobs.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView companyname, title, location;
        ImageView coverimage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            companyname = itemView.findViewById(R.id.companyname);
            title = itemView.findViewById(R.id.title);
            location = itemView.findViewById(R.id.location);
            coverimage = itemView.findViewById(R.id.coverImage);


        }
    }
}
