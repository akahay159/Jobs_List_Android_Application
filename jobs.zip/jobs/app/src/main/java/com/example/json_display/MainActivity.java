package com.example.json_display;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    // download manager library
    RecyclerView recyclerView;
    List<Jobs> jobs;
    // https://jobs.github.com/positions.json?page=1&search=code
    private static String URL ="https://jobs.github.com/positions.json?page=1&search=code";
            // for india jobs use this link"https://jobs.github.com/positions.json?description=python&location=india";
    Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.joblist);
        jobs = new ArrayList<>();
        // extrating the data and volley
        extractJobs();
        // set the layoutmanger to the recyclerview;


    }

    private void extractJobs() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, URL, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject jsonObject = response.getJSONObject(i);
                        Jobs job = new Jobs();
                        job.setCompanyName(jsonObject.getString("company").toString());
                        job.setTitle(jsonObject.getString("title").toString());
                        job.setLocation(jsonObject.getString("location").toString());
                        //song.setCoverImage(songObject.getString("cover_image"));
                        job.setImages(jsonObject.getString("company_logo"));
                        jobs.add(job);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                adapter = new Adapter(getApplicationContext(),jobs);
                recyclerView.setAdapter(adapter);
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("tag","onErrorResponse: "+ error.getMessage());
            }
        });
        requestQueue.add(jsonArrayRequest);
    }
}